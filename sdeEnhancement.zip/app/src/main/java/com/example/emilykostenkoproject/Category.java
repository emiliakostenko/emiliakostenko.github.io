package com.example.emilykostenkoproject;

import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class Category extends AppCompatActivity {
    private long currentUserId;
    private InventoryList mInventoryList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_category);

        mInventoryList = new InventoryList(this);
        currentUserId = getIntent().getLongExtra("userId", -1);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //print existing folders
        ArrayList<String> existingCategories = mInventoryList.getCategories(currentUserId);
        for (String categoryName : existingCategories) {
            addCategoryButton(categoryName);
        }
    }
    //add a category/folder
    public void addCategory(View view){
        final EditText folderName = new EditText(Category.this);

        new AlertDialog.Builder(Category.this)
                .setTitle("New Folder")
                .setMessage("Enter folder name")
                .setView(folderName)
                .setPositiveButton("OK", (dialog, which) -> {
                    String input = folderName.getText().toString();
                    if (!input.isEmpty()) {
                        // Check if category already exists
                        if (mInventoryList.categoryExists(input, currentUserId)) {
                            // Category exists
                            Toast.makeText(Category.this, "Category already exists", Toast.LENGTH_SHORT).show();
                        } else { // Category does not exist
                            mInventoryList.addCategory(input, currentUserId);

                            // add a button for this new category
                            addCategoryButton(input);
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    //sign out button
    public void SignOut(View view){
        Intent intent = new Intent(Category.this, MainActivity.class);
        ActivityOptions options = ActivityOptions.makeCustomAnimation(
                this,
                R.anim.slide_in_back,
                R.anim.slide_out_back
        );
        startActivity(intent, options.toBundle());
        finish();
    }
    //add category button
    private void addCategoryButton(String categoryName) {
        Button categoryButton = new Button(this);
        categoryButton.setText(categoryName);
        categoryButton.setAllCaps(false);
        categoryButton.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        // Set click listener
        categoryButton.setOnClickListener(v -> {
            Intent intent = new Intent(Category.this, MainScreen.class);
            intent.putExtra("userId", currentUserId);
            intent.putExtra("category", categoryName);
            ActivityOptions options = ActivityOptions.makeCustomAnimation(
                    this,
                    R.anim.slide_right,
                    R.anim.slide_left
            );
            startActivity(intent, options.toBundle());
        });

        // Add the button to the layout
        LinearLayout categorySection = findViewById(R.id.category_section);
        categorySection.addView(categoryButton);
    }

}