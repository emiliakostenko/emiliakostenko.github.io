package com.example.emilykostenkoproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UserDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "users.db";
    private static final int VERSION = 2;

    public UserDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
        private static final String COL_PHONE = "phone";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserTable.TABLE + " (" +
            UserTable.COL_ID + " integer primary key autoincrement, " +
            UserTable.COL_USERNAME + " text, " +
            UserTable.COL_PASSWORD + " text, " +
            UserTable.COL_PHONE + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }

    public long addUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserDatabase.UserTable.COL_USERNAME, user.getUsername());
        values.put(UserDatabase.UserTable.COL_PASSWORD, user.getPassword());
        values.put(UserDatabase.UserTable.COL_PHONE, user.getPhone());
        return db.insert(UserDatabase.UserTable.TABLE, null, values);
    }

    public long findUsersId(String username){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + UserDatabase.UserTable.COL_ID + " FROM " + UserDatabase.UserTable.TABLE + " WHERE " + UserDatabase.UserTable.COL_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        long userId = -1; // Default value if user not found

        if (cursor.moveToFirst()) {
            userId = cursor.getLong(cursor.getColumnIndexOrThrow(UserDatabase.UserTable.COL_ID));
        }

        cursor.close();
        db.close();

        return userId;
    }

    public boolean usernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM users WHERE username = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        boolean exists = cursor.moveToFirst(); // checks if row exists
        cursor.close();
        db.close();

        return exists;
    }

    public boolean userVerification(String username, String password){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + UserDatabase.UserTable.TABLE +
            " WHERE " + UserDatabase.UserTable.COL_USERNAME + " = ? AND " +
            UserDatabase.UserTable.COL_PASSWORD + " = ?";

        Cursor cursor = db.rawQuery(query, new String[]{username, password});
        boolean verified = cursor.moveToFirst(); // checks if row exists

        cursor.close();
        db.close();

        return verified;
    }

    public User getUserInfo(long id){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + UserDatabase.UserTable.TABLE + " WHERE " + UserDatabase.UserTable.COL_ID + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(id)});

        User user = null;
        if (cursor.moveToFirst()) {
            //retrieve contents
            String username = cursor.getString(cursor.getColumnIndexOrThrow(UserTable.COL_USERNAME));
            String password = cursor.getString(cursor.getColumnIndexOrThrow(UserTable.COL_PASSWORD));
            String phone = cursor.getString(cursor.getColumnIndexOrThrow(UserTable.COL_PHONE));

            //store in user object
            user = new User(id, username, password, phone);
        }

        cursor.close();
        db.close();
        return user;
    }
    public static String getTableName() {
        return UserTable.TABLE;
    }

    public static String getColId() {
        return UserTable.COL_ID;
    }

}
