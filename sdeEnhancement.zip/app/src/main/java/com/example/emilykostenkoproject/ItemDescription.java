package com.example.emilykostenkoproject;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ItemDescription extends AppCompatActivity {
    private long currentItemId;
    private boolean editing = false;

    ImageButton editButton;

    TextView descriptionText;
    EditText descriptionEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_item_description);

        //itemId from intent and views
        currentItemId = getIntent().getLongExtra("itemId", -1);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        descriptionText = findViewById(R.id.itemDescriptionText);
        descriptionEdit = findViewById(R.id.itemDescriptionEdit);
        editButton = findViewById(R.id.editButton);

        editButton.setOnClickListener(v -> editMode());

    }

    //back button
    public void backButtonDesc(View view){
        finish();
        overridePendingTransition(R.anim.slide_in_back, R.anim.slide_out_back);
    }

    //while in edit mode
    private void editMode(){
        if (!editing){
            //set to edit mode
            descriptionEdit.setText(descriptionText.getText().toString());
            descriptionText.setVisibility(View.GONE);
            descriptionEdit.setVisibility(View.VISIBLE);

            editButton.setImageResource(R.drawable.checkmark_icon);
            editing = true;
        } else {
            //exit edit mode
            String updatedDescription = descriptionEdit.getText().toString();
            descriptionText.setText(updatedDescription);

            descriptionEdit.setVisibility(View.GONE);
            descriptionText.setVisibility(View.VISIBLE);

            editButton.setImageResource(R.drawable.edit_icon);
            editing = false;

            //TODO: save to db
        }
    }
}