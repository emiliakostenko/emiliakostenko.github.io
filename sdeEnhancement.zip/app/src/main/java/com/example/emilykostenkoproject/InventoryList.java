package com.example.emilykostenkoproject;

import android.content.Context;
import android.database.Cursor;

import java.util.ArrayList;

public class InventoryList {
    private InventoryDatabase db;

    public InventoryList(Context context){
        db = new InventoryDatabase(context);
    }

    //adds an item to the list
    public void addItem(InventoryItem item, long userId, String category) throws IllegalArgumentException {
        db.addItem(item.getItemName(), item.getItemCount(), userId, category);
    }

    public void addCategory(String category, long userId) throws IllegalArgumentException {
        db.addCategory(category, userId);
    }
    //view all items
    public ArrayList<InventoryItem> getAllItems(long userId, String category) {
        return db.getAllItems(userId, category);
    }

    //view all categories
    public ArrayList<String> getCategories(long userId){
        return db.getCategories(userId);
    }

    //update count
    public boolean updateCount(long id, int count){
        return db.updateCount(id, count);
    }

    //delete item
    public boolean deleteItem(long id){
        return db.deleteItem(id);
    }

    //check if category exists
    public boolean categoryExists(String categoryName, long userId) {
        return db.categoryExists(categoryName, userId);
    }

}
