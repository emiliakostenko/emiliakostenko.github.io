package com.example.emilykostenkoproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class InventoryDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 6;

    public InventoryDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    //inventory table
    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_ITEM = "item";
        private static final String COL_COUNT = "count";
        private static final String COL_USERID = "userId";
        private static final String COL_CATEGORY = "category";

    }

    //category table
    private static final class CategoriesTable {
        private static final String TABLE = "categories";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_USERID = "userId";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //inventory table
        db.execSQL("create table " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " integer primary key autoincrement, " +
                InventoryTable.COL_ITEM + " text, " +
                InventoryTable.COL_COUNT + " int, " +
                InventoryTable.COL_USERID +" int, " +
                InventoryTable.COL_CATEGORY + " text, " +
                "foreign key(" + InventoryTable.COL_USERID + ") references " + UserDatabase.getTableName() + "(" + UserDatabase.getColId() + "))");

        //categories table
        db.execSQL("create table " + CategoriesTable.TABLE + " (" +
                CategoriesTable.COL_ID + " integer primary key autoincrement, " +
                CategoriesTable.COL_NAME + " text, " +
                CategoriesTable.COL_USERID + " int, " +
                "foreign key(" + CategoriesTable.COL_USERID + ") references " + UserDatabase.getTableName() + "(" + UserDatabase.getColId() + "))");

    }

    //on newer versions
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + InventoryDatabase.InventoryTable.TABLE);
        onCreate(db);
    }

    //add new category
    public void addCategory(String categoryName, long userId) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", categoryName);
        values.put("userId", userId);
        db.insert("categories", null, values);
        db.close();
    }

    //add inventory item
    public void addItem(String itemName, int itemCount, long userId, String category) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_ITEM, itemName);
        values.put(InventoryTable.COL_COUNT, itemCount);
        values.put("userId", userId);
        values.put("category", category);
        db.insert(InventoryTable.TABLE, null, values);
    }

    //retrieve arraylist of items in a category
    public ArrayList<InventoryItem> getAllItems(long userId, String category) {
        ArrayList<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
            "SELECT * FROM inventory WHERE userId = ? AND category = ?",
            new String[]{String.valueOf(userId), category}
        );

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryTable.COL_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(InventoryTable.COL_ITEM));
                int count = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryTable.COL_COUNT));

                items.add(new InventoryItem(id, name, count));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return items;
    }

    //check for existing category before adding
    public boolean categoryExists(String categoryName, long userId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM categories WHERE name = ? AND userId = ?",
                new String[]{categoryName, String.valueOf(userId)}
        );

        boolean exists = cursor.moveToFirst(); // true if a row exists
        cursor.close();
        db.close();
        return exists;
    }

    //retrieve categories
    public ArrayList<String> getCategories(long userId){
        ArrayList<String> categories = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + CategoriesTable.TABLE + " WHERE " + CategoriesTable.COL_USERID + " = ?",
                new String[]{String.valueOf(userId)}
        );

        if (cursor.moveToFirst()) {
            do {
                String category = cursor.getString(cursor.getColumnIndexOrThrow(CategoriesTable.COL_NAME));
                categories.add(category);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return categories;
    }

    //update count on inventory item
    public boolean updateCount(long id, int count) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_COUNT, count);

        int rowsUpdated = db.update(InventoryTable.TABLE, values, InventoryTable.COL_ID + " = ?",
                new String[] { String.valueOf(id) });
        return rowsUpdated > 0;
    }

    //delete item
    public boolean deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(InventoryTable.TABLE, InventoryTable.COL_ID + " = ?",
                new String[] { Long.toString(id) });
        return rowsDeleted > 0;
    }
}
