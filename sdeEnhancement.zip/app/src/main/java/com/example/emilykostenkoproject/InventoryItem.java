package com.example.emilykostenkoproject;

public class InventoryItem {
    private int id;
    private String itemName;
    private int itemCount;

    public InventoryItem(int id, String itemName, int itemCount) {
        this.id = id;
        this.itemName = itemName;
        this.itemCount = itemCount;
    }

    public int getId() {
        return id;
    }

    public String getItemName() {
        return itemName;
    }

    public int getItemCount() {
        return itemCount;
    }


    public void setId(int id) {
        this.id = id;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setItemCount(int itemCount) {
        this.itemCount = itemCount;
    }

}
