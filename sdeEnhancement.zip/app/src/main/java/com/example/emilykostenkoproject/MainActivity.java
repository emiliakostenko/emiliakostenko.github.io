package com.example.emilykostenkoproject;

import android.app.ActivityOptions;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText userNameText;
    private Button buttonLogin;
    private EditText passwordText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        userNameText = findViewById(R.id.userNameText);
        passwordText = findViewById(R.id.passwordText);
        buttonLogin = findViewById(R.id.buttonLogin);

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String username = userNameText.getText().toString().trim();
                String password = passwordText.getText().toString().trim();
                buttonLogin.setEnabled(!username.isEmpty() && !password.isEmpty());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        };

        userNameText.addTextChangedListener(textWatcher);
        passwordText.addTextChangedListener(textWatcher);
    }
    public void Login(View view) {
        String username = userNameText.getText().toString().trim();
        String password = passwordText.getText().toString().trim();
        UserDatabase db = new UserDatabase(this);

        if (db.usernameExists(username)) {
            if (db.userVerification(username, password)) {
                Intent intent = new Intent(MainActivity.this, Category.class);
                //send userid so their items load
                long userId = db.findUsersId(username);
                intent.putExtra("userId", userId);

                //transition
                ActivityOptions options = ActivityOptions.makeCustomAnimation(
                        this,
                        R.anim.slide_right,
                        R.anim.slide_left   // exit animation
                );

                startActivity(intent, options.toBundle());
                finish();
            } else {
                Toast.makeText(this, "Username or Password Incorrect", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "Username does not exist", Toast.LENGTH_LONG).show();
        }
    }

    public void CreateAccount(View view){
        Intent intent = new Intent(MainActivity.this, CreateNewAccount.class);
        ActivityOptions options = ActivityOptions.makeCustomAnimation(
                this,
                R.anim.slide_right,
                R.anim.slide_left   // exit animation
        );

        startActivity(intent, options.toBundle());
        finish();
    }
}