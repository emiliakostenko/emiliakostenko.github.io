package com.example.emilykostenkoproject;

import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainScreen extends AppCompatActivity {
    private InventoryList mInventoryList;
    private long currentUserId;
    private String currentCategory;
    private EditText searchBarEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.main_screen);

        // Get userId and category from intent and views
        currentUserId = getIntent().getLongExtra("userId", -1);
        currentCategory = getIntent().getStringExtra("category");
        initWidgets();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //listener
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                //TODO watch searchbar for search feature with BST
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }
        };

        searchBarEditText.addTextChangedListener(textWatcher);
        mInventoryList = new InventoryList(this);
        displayItems();
    }

    @Override
    protected void onResume() {
        super.onResume();
        displayItems();
    }

    //extract views
    private void initWidgets(){
        searchBarEditText = findViewById(R.id.search_bar);
    }

    //Add item button
    public void addItem(View view){
        Intent intent = new Intent(MainScreen.this, AddInventoryItem.class);
        intent.putExtra("userId", currentUserId);
        intent.putExtra("category", currentCategory);
        ActivityOptions options = ActivityOptions.makeCustomAnimation(
                this,
                R.anim.slide_right,
                R.anim.slide_left
        );

        startActivity(intent, options.toBundle());
        finish();
    }


    //back button
    public void backButton(View view){
        finish();
        overridePendingTransition(R.anim.slide_in_back, R.anim.slide_out_back);
    }

    //display all inventory items and buttons for managing amounts
    private void displayItems() {
        ArrayList<InventoryItem> items = mInventoryList.getAllItems(currentUserId, currentCategory);
        GridLayout gridLayout = findViewById(R.id.item_grid);

        gridLayout.removeAllViews();
        int row = 0;

        int totalColumns = 5;
        gridLayout.setColumnCount(totalColumns);

        for (InventoryItem item : items) {
            // layout params for all cells
            GridLayout.LayoutParams baseParams;

            // Item name
            Button nameButton = new Button(this);
            nameButton.setText(item.getItemName());
            nameButton.setTextSize(15);
            nameButton.setAllCaps(false);
            nameButton.setForeground(null);
            nameButton.setBackground(null);
            nameButton.setTypeface(null, Typeface.BOLD);
            nameButton.setPadding(0, 0, 0, 0);
            nameButton.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            baseParams = new GridLayout.LayoutParams(
                    GridLayout.spec(row),
                    GridLayout.spec(0, 1f)
            );
            baseParams.width = 0; // let weight handle width
            baseParams.setMargins(8, 8, 8, 8);
            gridLayout.addView(nameButton, baseParams);

            nameButton.setOnClickListener(v -> {
                Intent intent = new Intent(MainScreen.this, ItemDescription.class);
                intent.putExtra("itemId", item.getId());

                ActivityOptions options = ActivityOptions.makeCustomAnimation(
                        this,
                        R.anim.slide_right,
                        R.anim.slide_left
                );
                startActivity(intent, options.toBundle());
            });

            // Count
            TextView countView = new TextView(this);
            countView.setText(String.valueOf(item.getItemCount()));
            countView.setTextSize(15);
            countView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            baseParams = new GridLayout.LayoutParams(
                    GridLayout.spec(row),
                    GridLayout.spec(1, 1f)
            );
            baseParams.width = 0;
            baseParams.setMargins(8, 8, 8, 8);
            gridLayout.addView(countView, baseParams);

            // + Button
            Button plusButton = new Button(this);
            plusButton.setText("+");
            baseParams = new GridLayout.LayoutParams(
                    GridLayout.spec(row),
                    GridLayout.spec(2, 1f)
            );
            baseParams.width = 0;
            baseParams.setMargins(8, 8, 8, 8);
            gridLayout.addView(plusButton, baseParams);

            //click listener to manage inventory count
            plusButton.setOnClickListener(v -> {
                int newCount = item.getItemCount() + 1;
                item.setItemCount(newCount);
                mInventoryList.updateCount(item.getId(), newCount);
                displayItems();
            });

            //long click listener to alter inventory count by custom amount
            plusButton.setOnLongClickListener(v -> {
                //create edit text for user input
                final EditText input = new EditText(MainScreen.this);
                input.setInputType(InputType.TYPE_CLASS_NUMBER);

                //create dialog for user to enter amount
                new AlertDialog.Builder(MainScreen.this)
                        .setTitle("Subtract Inventory")
                        .setMessage("Enter a custom amount to add to inventory:")
                        .setView(input)
                        .setPositiveButton("OK", (dialog, which) -> {
                            String inputValue = input.getText().toString();
                            if (!inputValue.isEmpty()) {
                                int customAmount = Integer.parseInt(inputValue);
                                int newCount = (item.getItemCount() + customAmount);
                                item.setItemCount(newCount);
                                mInventoryList.updateCount(item.getId(), newCount);
                                displayItems();
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();

                return true;
            });

            // - Button
            Button minusButton = new Button(this);
            minusButton.setText("-");
            baseParams = new GridLayout.LayoutParams(
                    GridLayout.spec(row),
                    GridLayout.spec(3, 1f)
            );
            baseParams.width = 0;
            baseParams.setMargins(8, 8, 8, 8);
            gridLayout.addView(minusButton, baseParams);

            //click listener to manage inventory count
            minusButton.setOnClickListener(v -> {
                if (item.getItemCount() > 0) {
                    int newCount = item.getItemCount() - 1;
                    item.setItemCount(newCount);
                    mInventoryList.updateCount(item.getId(), newCount);
                    displayItems();
                }
                //low stock SMS
                if (item.getItemCount() <= 2) {
                    sendLowStockSMS(item.getItemName());
                }
            });

            //long click listener to alter inventory count by custom amount
            minusButton.setOnLongClickListener(v -> {
                //create edit text for user input
                final EditText input = new EditText(MainScreen.this);
                input.setInputType(InputType.TYPE_CLASS_NUMBER);

                //create dialog for user to enter amount
                new AlertDialog.Builder(MainScreen.this)
                    .setTitle("Subtract Inventory")
                    .setMessage("Enter a custom amount to subtract from inventory:")
                    .setView(input)
                    .setPositiveButton("OK", (dialog, which) -> {
                        String inputValue = input.getText().toString();
                        if (!inputValue.isEmpty()) {
                            int customAmount = Integer.parseInt(inputValue);
                            int newCount = Math.max(0, item.getItemCount() - customAmount);
                            item.setItemCount(newCount);
                            mInventoryList.updateCount(item.getId(), newCount);
                            displayItems();

                            // Low stock SMS
                            if (newCount <= 2) {
                                sendLowStockSMS(item.getItemName());
                            }
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();

                return true;
            });


            // X Button
            Button trashButton = new Button(this);
            trashButton.setText("X");
            baseParams = new GridLayout.LayoutParams(
                    GridLayout.spec(row),
                    GridLayout.spec(4, 1f)
            );
            baseParams.width = 0;
            baseParams.setMargins(8, 8, 8, 8);
            gridLayout.addView(trashButton, baseParams);

            trashButton.setOnClickListener(v -> {
                mInventoryList.deleteItem(item.getId());
                displayItems();
            });

            row++;
        }
    }

    //low stock SMS feature
    public void sendLowStockSMS(String item) {
        UserDatabase userDb = new UserDatabase(this);
        User currentUser = userDb.getUserInfo(currentUserId);
        String message = "Reorder needed. " + item + " is low on stock.";

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            if (currentUser.getPhone() != null) {
                String phone = currentUser.getPhone();
                SmsManager smsManager;

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    smsManager = getSystemService(SmsManager.class);
                } else {
                    smsManager = SmsManager.getDefault();
                }
                //for debugging
                //Log.d("SMS_DEBUG", "Sending SMS to " + phone + ": " + message);
                //Toast.makeText(this, "Simulated SMS: " + message, Toast.LENGTH_SHORT).show();

                smsManager.sendTextMessage(phone, null, message, null, null);
                Toast.makeText(this, "Low stock alert sent for " + item, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "User not found. Cannot send SMS.", Toast.LENGTH_SHORT).show();
            }
        } else { return; } //permission not granted
    }

    //cancel search button - clears the search bar
    public void cancelSearch(View view){
        EditText searchBar;
        searchBar = findViewById(R.id.search_bar);

        searchBar.setText("");
    }
}