package com.example.emilykostenkoproject;

import android.app.ActivityOptions;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddInventoryItem extends AppCompatActivity {
    private Button AddInventoryButton;
    private EditText ItemEditText;
    private EditText ItemCountText;
    private InventoryList mInventoryList;
    private long currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_inventory_item);
        currentUserId = getIntent().getLongExtra("userId", -1);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        initWidgets();

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String item = ItemEditText.getText().toString().trim();
                String itemCount = ItemCountText.getText().toString().trim();
                AddInventoryButton.setEnabled(!item.isEmpty() && !itemCount.isEmpty());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        };

        ItemEditText.addTextChangedListener(textWatcher);
        ItemCountText.addTextChangedListener(textWatcher);
    }
    private void initWidgets(){
        ItemEditText = findViewById(R.id.ItemEditText);
        ItemCountText = findViewById(R.id.ItemCountText);
        AddInventoryButton = findViewById(R.id.AddInventoryButton);
        mInventoryList = new InventoryList(this);
    }

    public void addInventoryItem(View view){
        String item = ItemEditText.getText().toString().trim();
        int itemCount = Integer.parseInt(ItemCountText.getText().toString().trim());

        //add item
        InventoryItem newItem = new InventoryItem(0, item, itemCount);

        //set edit texts to blank
        ItemEditText.setText("");
        ItemCountText.setText("");

        mInventoryList.addItem(newItem, currentUserId);
        Toast.makeText(this, "Item added!", Toast.LENGTH_SHORT).show();

    }
    public void Cancel(View view){
        Intent intent = new Intent(AddInventoryItem.this, MainScreen.class);
        intent.putExtra("userId", currentUserId);
        ActivityOptions options = ActivityOptions.makeCustomAnimation(
                this,
                R.anim.slide_in_back,
                R.anim.slide_out_back
        );

        startActivity(intent, options.toBundle());
        finish();
    }
}