package com.example.emilykostenkoproject;

import android.Manifest;
import android.app.ActivityOptions;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.DialogInterface;
import androidx.appcompat.app.AlertDialog;


import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CreateNewAccount extends AppCompatActivity {
    private EditText userNameText;
    private EditText phoneText;
    private Button buttonCreateAccount;
    private EditText passwordText;
    private long userId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_new_account);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        userNameText = findViewById(R.id.userNameText);
        passwordText = findViewById(R.id.passwordText);
        phoneText = findViewById(R.id.phoneText);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String username = userNameText.getText().toString().trim();
                String password = passwordText.getText().toString().trim();
                String phone = phoneText.getText().toString().trim();
                buttonCreateAccount.setEnabled(!username.isEmpty() && !password.isEmpty() && !phone.isEmpty());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        };

        userNameText.addTextChangedListener(textWatcher);
        passwordText.addTextChangedListener(textWatcher);
        phoneText.addTextChangedListener(textWatcher);
    }

    public void CreateAccount(View view){
        String username = userNameText.getText().toString().trim();
        String password = passwordText.getText().toString().trim();
        String phone = phoneText.getText().toString().trim();
        UserDatabase db = new UserDatabase(this);

        if (db.usernameExists(username)) {
            Toast.makeText(this, "Username already taken, please choose another one.", Toast.LENGTH_SHORT).show();
            return;
        }

        //create new user
        User newUser = new User(0, username, password, phone);

        //add user to database
        long result = db.addUser(newUser);

        if (result != -1) {
            long userId = db.findUsersId(username);

            //SMS permission
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                sendSMS();
                goToMainScreen(userId);
            } else if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                showSmsRationaleDialog(userId);
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 100);
                this.userId = userId;
            }
        }
    }

    private void showSmsRationaleDialog(long userId) {
        new AlertDialog.Builder(this)
                .setTitle("SMS Permission Requested")
                .setMessage("We require permission to send SMS messages so we can send you text notifications regarding low inventory levels")
                .setPositiveButton("Allow", (dialog, which) -> {
                    this.userId = userId; // save so we can use it after permission result
                    ActivityCompat.requestPermissions(CreateNewAccount.this,
                            new String[]{Manifest.permission.SEND_SMS}, 100);
                })
                .setNegativeButton("Deny", (dialog, which) -> {
                    dialog.dismiss();
                    Toast.makeText(CreateNewAccount.this, "SMS notifications denied", Toast.LENGTH_LONG).show();
                    goToMainScreen(userId);
                })
                .create()
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults){
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            sendSMS();
        } else {
            Toast.makeText(this, "Permission Denied to send text message", Toast.LENGTH_SHORT).show();
        }
        goToMainScreen(userId); // use the saved userId from earlier
    }

    public void sendSMS(){
        String phone = phoneText.getText().toString().trim();
        String message = "You have successfully signed up for text message notifications!";

        if (!phone.isEmpty()){
            SmsManager smsManager;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                smsManager = getSystemService(SmsManager.class);
            } else {
                smsManager = SmsManager.getDefault();
            }
            //debug texts
            //Log.d("SMS_DEBUG", "Sending SMS to " + phone + ": " + message);
            //Toast.makeText(this, "Simulated SMS: " + message, Toast.LENGTH_SHORT).show();

            smsManager.sendTextMessage(phone, null, message,null, null);
            Toast.makeText(this, "Confirmation text sent!", Toast.LENGTH_SHORT).show();
        }
    }
    private void goToMainScreen(long userId) {
        Intent intent = new Intent(this, MainScreen.class);
        intent.putExtra("userId", userId);
        ActivityOptions options = ActivityOptions.makeCustomAnimation(
                this,
                R.anim.slide_right,
                R.anim.slide_left   // exit animation
        );

        startActivity(intent, options.toBundle());
        finish();
    }

}