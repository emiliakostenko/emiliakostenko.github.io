package com.example.emilykostenkoproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class InventoryDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 3;

    public InventoryDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_ITEM = "item";
        private static final String COL_COUNT = "count";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " integer primary key autoincrement, " +
                InventoryTable.COL_ITEM + " text, " +
                InventoryTable.COL_COUNT + " int, " +
                "user_id INTEGER, " +
                "foreign key(user_id) references " + UserDatabase.getTableName() + "(" + UserDatabase.getColId() + "))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + InventoryDatabase.InventoryTable.TABLE);
        onCreate(db);
    }

    public long addItem(String itemName, int itemCount, long userId) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_ITEM, itemName);
        values.put(InventoryTable.COL_COUNT, itemCount);
        values.put("user_id", userId);
        return db.insert(InventoryTable.TABLE, null, values);
    }

    public ArrayList<InventoryItem> getAllItems(long userId) {
        ArrayList<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
            "SELECT * FROM inventory WHERE user_id = ?",
            new String[]{String.valueOf(userId)}
        );

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryTable.COL_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(InventoryTable.COL_ITEM));
                int count = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryTable.COL_COUNT));

                items.add(new InventoryItem(id, name, count));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return items;
    }
    public boolean updateCount(long id, int count) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_COUNT, count);

        int rowsUpdated = db.update(InventoryTable.TABLE, values, InventoryTable.COL_ID + " = ?",
                new String[] { String.valueOf(id) });
        return rowsUpdated > 0;
    }


    public boolean deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(InventoryTable.TABLE, InventoryTable.COL_ID + " = ?",
                new String[] { Long.toString(id) });
        return rowsDeleted > 0;
    }
}
