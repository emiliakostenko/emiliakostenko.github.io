package com.example.emilykostenkoproject;

import android.content.Context;

import java.util.ArrayList;

public class InventoryList {
    private InventoryDatabase db;

    public InventoryList(Context context){
        db = new InventoryDatabase(context);
    }

    //adds an item to the list
    public void addItem(InventoryItem item, long userId) throws IllegalArgumentException {
        db.addItem(item.getItemName(), item.getItemCount(), userId);
    }

    //view all items
    public ArrayList<InventoryItem> getAllItems(long userId) {
        return db.getAllItems(userId);
    }

    //update count
    public boolean updateCount(long id, int count){
        return db.updateCount(id, count);
    }

    //delete item
    public boolean deleteItem(long id){
        return db.deleteItem(id);
    }
}
