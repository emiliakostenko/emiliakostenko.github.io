package com.example.emilykostenkoproject;

import android.app.ActivityOptions;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainScreen extends AppCompatActivity {
    private InventoryList mInventoryList;
    private long currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.main_screen);

        // Get userId from intent
        currentUserId = getIntent().getLongExtra("userId", -1);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        mInventoryList = new InventoryList(this);
        displayItems();
    }

    @Override
    protected void onResume() {
        super.onResume();
        displayItems();
    }
    public void addItem(View view){
        Intent intent = new Intent(MainScreen.this, AddInventoryItem.class);
        intent.putExtra("userId", currentUserId);
        ActivityOptions options = ActivityOptions.makeCustomAnimation(
                this,
                R.anim.slide_right,
                R.anim.slide_left
        );

        startActivity(intent, options.toBundle());
        finish();
    }
    public void SignOut(View view){
        Intent intent = new Intent(MainScreen.this, MainActivity.class);
        ActivityOptions options = ActivityOptions.makeCustomAnimation(
                this,
                R.anim.slide_in_back,
                R.anim.slide_out_back
        );
        startActivity(intent, options.toBundle());
        finish();
    }
    private void displayItems() {
        ArrayList<InventoryItem> items = mInventoryList.getAllItems(currentUserId);
        GridLayout gridLayout = findViewById(R.id.item_grid);

        gridLayout.removeAllViews();
        int row = 0;

        int totalColumns = 5;
        gridLayout.setColumnCount(totalColumns);

        for (InventoryItem item : items) {
            // Common layout params for all cells
            GridLayout.LayoutParams baseParams;

            // Item name
            TextView nameView = new TextView(this);
            nameView.setText(item.getItemName());
            nameView.setTextSize(15);
            nameView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            baseParams = new GridLayout.LayoutParams(
                    GridLayout.spec(row),
                    GridLayout.spec(0, 1f)
            );
            baseParams.width = 0; // let weight handle width
            baseParams.setMargins(8, 8, 8, 8);
            gridLayout.addView(nameView, baseParams);

            // Count
            TextView countView = new TextView(this);
            countView.setText(String.valueOf(item.getItemCount()));
            countView.setTextSize(15);
            countView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            baseParams = new GridLayout.LayoutParams(
                    GridLayout.spec(row),
                    GridLayout.spec(1, 1f)
            );
            baseParams.width = 0;
            baseParams.setMargins(8, 8, 8, 8);
            gridLayout.addView(countView, baseParams);

            // + Button
            Button plusButton = new Button(this);
            plusButton.setText("+");
            baseParams = new GridLayout.LayoutParams(
                    GridLayout.spec(row),
                    GridLayout.spec(2, 1f)
            );
            baseParams.width = 0;
            baseParams.setMargins(8, 8, 8, 8);
            gridLayout.addView(plusButton, baseParams);

            plusButton.setOnClickListener(v -> {
                int newCount = item.getItemCount() + 1;
                item.setItemCount(newCount);
                mInventoryList.updateCount(item.getId(), newCount);
                displayItems();
            });

            // - Button
            Button minusButton = new Button(this);
            minusButton.setText("-");
            baseParams = new GridLayout.LayoutParams(
                    GridLayout.spec(row),
                    GridLayout.spec(3, 1f)
            );
            baseParams.width = 0;
            baseParams.setMargins(8, 8, 8, 8);
            gridLayout.addView(minusButton, baseParams);

            minusButton.setOnClickListener(v -> {
                if (item.getItemCount() > 0) {
                    int newCount = item.getItemCount() - 1;
                    item.setItemCount(newCount);
                    mInventoryList.updateCount(item.getId(), newCount);
                    displayItems();
                }
                //low stock SMS
                if (item.getItemCount() <= 2) {
                    sendLowStockSMS(item.getItemName());
                }
            });

            // X Button
            Button trashButton = new Button(this);
            trashButton.setText("X");
            baseParams = new GridLayout.LayoutParams(
                    GridLayout.spec(row),
                    GridLayout.spec(4, 1f)
            );
            baseParams.width = 0;
            baseParams.setMargins(8, 8, 8, 8);
            gridLayout.addView(trashButton, baseParams);

            trashButton.setOnClickListener(v -> {
                mInventoryList.deleteItem(item.getId());
                displayItems();
            });

            row++;
        }
    }
    public void sendLowStockSMS(String item) {
        UserDatabase userDb = new UserDatabase(this);
        User currentUser = userDb.getUserInfo(currentUserId);
        String message = "Reorder needed. " + item + " is low on stock.";

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            if (currentUser.getPhone() != null) {
                String phone = currentUser.getPhone();
                SmsManager smsManager;

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    smsManager = getSystemService(SmsManager.class);
                } else {
                    smsManager = SmsManager.getDefault();
                }
                //for debugging
                //Log.d("SMS_DEBUG", "Sending SMS to " + phone + ": " + message);
                //Toast.makeText(this, "Simulated SMS: " + message, Toast.LENGTH_SHORT).show();

                smsManager.sendTextMessage(phone, null, message, null, null);
                Toast.makeText(this, "Low stock alert sent for " + item, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "User not found. Cannot send SMS.", Toast.LENGTH_SHORT).show();
            }
        } else { return; } //permission not granted
    }
}